

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class stored extends HttpServlet {

   
    protected void service(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");
         PrintWriter out = res.getWriter();
         try {
            res.setContentType("text/html;charset=UTF-8");

            String Eid = req.getParameter("Eid");
            String EName = req.getParameter("EName");
            String DOJ = req.getParameter("DOJ");
            String YOE = req.getParameter("YOE");
            String Designation = req.getParameter("Designation");
      
           

           
            Class.forName("com.mysql.jdbc.Driver");

            Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/empdb", "root", "hero");
            PreparedStatement stmt = con.prepareStatement("insert into empinfo values(?,?,?,?,?)");
            stmt.setString(1, Eid);
            stmt.setString(2, EName);
            stmt.setString(3, DOJ);
            stmt.setString(4, YOE);
            stmt.setString(5, Designation);
            
            stmt.executeUpdate();
            RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
            rd.include(req, res);
    }   catch (ClassNotFoundException ex) {
           out.print(ex);
        } catch (SQLException ex) {
             out.print(ex);
            Logger.getLogger(stored.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
           

  